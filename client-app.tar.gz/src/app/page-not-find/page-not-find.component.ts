import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-find',
  templateUrl: './page-not-find.component.html',
  styleUrls: ['./page-not-find.component.css']
})
export class PageNotFindComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
