export class Zone {
	constructor(
		public id: number | string, 
		public name: string, 
		public key:string,
		public createdAt: string,
		public updatedAt: string
		){}
}