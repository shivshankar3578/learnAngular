import { Component, OnInit } from '@angular/core';
import { MdDialogRef } from '@angular/material';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Zone } from './zones.model';
import { ZoneService } from './zones.service';

@Component({
	selector: 'app-zones-view',
	templateUrl: './zones-view.component.html',
	styleUrls: ['./zones-view.component.css']
})
export class ZonesViewComponent implements OnInit {
	public zoneForm: FormGroup;
	public isEdit: boolean;
	private zone: Zone;
	constructor(
		private formBuilder: FormBuilder,
		private zoneService: ZoneService,
		public dialogRef: MdDialogRef<ZonesViewComponent>
		) {
			this.isEdit = false;
		}

	ngOnInit() {
		this.zone = this.zoneService.zone;
		// console.log("zone oninit", this.zone)
		if(this.zone.id){
			this.isEdit = true;
			this.loadForm();
		}else{
			this.isEdit = false;
			this.loadForm();
		}
	}
	loadForm(){
		// console.log("loadfrom called")
		this.zoneForm = new FormGroup({
			name: new FormControl(this.zone.name, [<any>Validators.required, <any>Validators.minLength(5)]),
			key: new FormControl( this.zone.key, [<any>Validators.required]),
		});
	}
	onSearch(model: Zone, isValid: boolean) {
		// console.log("model submit called", )

		return this.dialogRef.close('success');
	}

}
